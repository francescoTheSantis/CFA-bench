git clone https://github.com/lucagioacchini/remote-web.git
cd remote-web
./server_install.sh
pip3 install -e .

cd ..
pip3 install -e .